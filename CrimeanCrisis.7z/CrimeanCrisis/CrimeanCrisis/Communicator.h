#pragma once

class Communicator
{
public:
	Communicator();
	~Communicator();
};

