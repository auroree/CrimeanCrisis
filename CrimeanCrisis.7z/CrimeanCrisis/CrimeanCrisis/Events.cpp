#include "Events.h"


Events::Events()
{
}


Events::~Events()
{
}
