#pragma once

class Events
{
public:
	Events();
	~Events();
};

