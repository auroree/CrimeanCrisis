#include "GraphicObject.h"

GraphicObject::GraphicObject()
{
	normals = new float;
	Faces_Triangles = new float;
	vertexBuffer = new float;
	*normals = NULL;
	*Faces_Triangles = NULL;
	*vertexBuffer = NULL;

	this->TotalConnectedTriangles = 0;
	this->TotalConnectedPoints = 0;
	this->pos.x = 0.0;
	this->pos.y = 3.5;
	this->pos.z = 10.0; 
	this->Color[0] = 0.75;
	this->Color[1] = 1.0;
	this->Color[2] = 0.65;
	this->Color[4] = 1.0;
}


GraphicObject::~GraphicObject()
{
}

GraphicObject GraphicObject::operator=(const GraphicObject &rhs)
{
	delete normals;
	delete Faces_Triangles;
	delete vertexBuffer;
	normals = new float;
	Faces_Triangles = new float;
	vertexBuffer = new float;
	*normals = *rhs.normals;
	*Faces_Triangles = *rhs.Faces_Triangles;
	*vertexBuffer = *rhs.vertexBuffer;

	this->Color[0] = rhs.Color[0];
	this->Color[1] = rhs.Color[1];
	this->Color[2] = rhs.Color[2];
	this->Color[3] = rhs.Color[3];
	this->Color[4] = rhs.Color[4];
	
	this->OBJnormals = rhs.OBJnormals;
	this->OBJuvs = rhs.OBJuvs;
	this->OBJvertices = rhs.OBJvertices;

	this->pos.x = rhs.pos.x;
	this->pos.y = rhs.pos.y;
	this->pos.z = rhs.pos.z;

	this->TotalConnectedPoints;
	this->TotalConnectedTriangles;
	this->uvIndices = rhs.uvIndices;
	this->normalIndices = rhs.normalIndices;
	
	this->vertexIndices = rhs.vertexIndices;

	return *this;
}

vector< glm::vec3 > GraphicObject::getVertices()
{
	return this->OBJvertices;
}

bool GraphicObject::loadOBJ(const char * path, const char * texturePath)
{
	vector< glm::vec3 > temp_vertices;
	vector< glm::vec2 > temp_uvs;
	vector< glm::vec3 > temp_normals;

	FILE * file = fopen(path, "r");
	if (file == NULL)
	{
		printf("Impossible to open the file!\n");
		return false;
	}

	while (1)
	{
		char lineHeader[128];
		// read the first word of the line
		int res = fscanf(file, "%s", lineHeader);
		if (res == EOF)
			break;

		if (strcmp(lineHeader, "v") == 0)
		{
			vec3 vertex;
			fscanf(file, "%f %f %f\n", &vertex.x, &vertex.y, &vertex.z);
			temp_vertices.push_back(vertex);
		}
		else if (strcmp(lineHeader, "vt") == 0)
		{
			vec2 uv;
			fscanf(file, "%f %f\n", &uv.x, &uv.y);
			temp_uvs.push_back(uv);
		}
		else if (strcmp(lineHeader, "vn") == 0)
		{
			vec3 normal;
			fscanf(file, "%f %f %f\n", &normal.x, &normal.y, &normal.z);
			temp_normals.push_back(normal);
		}
		else if (strcmp(lineHeader, "f") == 0)
		{
			string vertex1, vertex2, vertex3;
			unsigned int vertexIndex[3], uvIndex[3], normalIndex[3];
			int matches = fscanf(file, "%d/%d/%d %d/%d/%d %d/%d/%d\n", &vertexIndex[0], &uvIndex[0], &normalIndex[0], &vertexIndex[1], &uvIndex[1], &normalIndex[1], &vertexIndex[2], &uvIndex[2], &normalIndex[2]);
			// printf("%d/%d/%d %d/%d/%d %d/%d/%d\n", vertexIndex[0], uvIndex[0], normalIndex[0], vertexIndex[1], uvIndex[1], normalIndex[1], vertexIndex[2], uvIndex[2], normalIndex[2]);
			if (matches != 9)
			{
				printf("File can't be read by this simple parser. Try exporting with other options or check for untextured parts.\n");
				return false;
			}

			this->vertexIndices.push_back(vertexIndex[0]);
			this->vertexIndices.push_back(vertexIndex[1]);
			this->vertexIndices.push_back(vertexIndex[2]);
			this->uvIndices.push_back(uvIndex[0]);
			this->uvIndices.push_back(uvIndex[1]);
			this->uvIndices.push_back(uvIndex[2]);
			this->normalIndices.push_back(normalIndex[0]);
			this->normalIndices.push_back(normalIndex[1]);
			this->normalIndices.push_back(normalIndex[2]);
		}
	}

	// Indexing..
	for (unsigned int i = 0; i < vertexIndices.size(); i++)
	{
		unsigned int vertexIndex = vertexIndices[i];
		vec3 vertex = temp_vertices[vertexIndex - 1];
		//out_vertices.push_back(vertex);
		this->OBJvertices.push_back(vertex);
	}
	for (unsigned int i = 0; i < uvIndices.size(); i++)
	{
		unsigned int uvIndex = uvIndices[i];
		vec2 uv = temp_uvs[uvIndex - 1];
		//out_uvs.push_back(uv);
		this->OBJuvs.push_back(uv);
	}
	for (unsigned int i = 0; i < normalIndices.size(); i++)
	{
		unsigned int normalIndex = normalIndices[i];
		vec3 normal = temp_normals[normalIndex - 1];
		//out_normals.push_back(normal);
		this->OBJnormals.push_back(normal);
	}

	printf(".OBJ file opened successfully.\n");
	if(loadTexture(texturePath))
		printf("Texture opened successfully.\n");

	printf("Read data fragment: \nVertices\tUVs\t\tNormals\n");
	for (int i = 1; i < 512; i*=2)
	{
		printf("%f\t%f\t%f\n", OBJvertices[i], OBJuvs[i], OBJnormals[i]);
	}
	return true;
}

bool GraphicObject::loadTexture(const char* path) {
	GLuint loadBMP_custom(*path);

	// Data read from the header of the BMP file
	unsigned char header[54]; // Each BMP file begins by a 54-bytes header
	unsigned int dataPos;     // Position in the file where the actual data begins
	unsigned int width, height;
	unsigned int imageSize;   // = width*height*3
	// Actual RGB data
	unsigned char * data;

	// Open the file
	FILE * file = fopen(path, "rb");
	if (!file) 
	{
		printf("Image could not be opened\n");
		return false;
	}

	if (fread(header, 1, 54, file) != 54)
	{ 
		printf("Not a correct BMP file\n");
		return false;
	}

	if (header[0] != 'B' || header[1] != 'M')
	{
		printf("Not a correct BMP file\n");
		return false;
	}

	// Read ints from the byte array
	dataPos = *(int*)&(header[0x0A]);
	imageSize = *(int*)&(header[0x22]);
	width = *(int*)&(header[0x12]);
	height = *(int*)&(header[0x16]);

	// Some BMP files are misformatted, guess missing information
	if (imageSize == 0)
		imageSize = width*height * 3;
	if (dataPos == 0)
		dataPos = 54;

	// Create a buffer
	data = new unsigned char[imageSize];

	fread(data, 1, imageSize, file);	// Read the actual data from the file into the buffer
	fclose(file);						//Everything is in memory now, the file can be closed

	GLuint textureID;
	glGenTextures(1, &textureID);
	glBindTexture(GL_TEXTURE_2D, textureID);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_BGR, GL_UNSIGNED_BYTE, data);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	return true;
}

//////////////////////// NOWE METODY /////////////////////////////

int GraphicObject::alternateLoad(char *path)
{
	string line;
	ifstream objFile(path);
	if (objFile.is_open())													// If obj file is open, continue
	{
		objFile.seekg(0, ios::end);										// Go to end of the file, 
		long fileSize = objFile.tellg();									// get file size
		objFile.seekg(0, ios::beg);										// we'll use this to register memory for our 3d model

		vertexBuffer = (float*)malloc(fileSize);							// Allocate memory for the verteces
		Faces_Triangles = (float*)malloc(fileSize*sizeof(float));			// Allocate memory for the triangles
		normals = (float*)malloc(fileSize*sizeof(float));					// Allocate memory for the normals

		int triangle_index = 0;												// Set triangle index to zero
		int normal_index = 0;												// Set normal index to zero

		while (!objFile.eof())												// Start reading file data
		{
			getline(objFile, line);											// Get line from file
			if (line.c_str()[0] == 'v')										// The first character is a v: on this line is a vertex stored.
			{
				line[0] = ' ';												// Set first character to 0. This will allow us to use sscanf
				sscanf(line.c_str(), "%f %f %f ", &vertexBuffer[TotalConnectedPoints], 
					&vertexBuffer[TotalConnectedPoints + 1], 
					&vertexBuffer[TotalConnectedPoints + 2]);
				TotalConnectedPoints += POINTS_PER_VERTEX;					// Add 3 to the total connected points
			}
			else if (line.c_str()[0] == 'f')								// The first character is an 'f': on this line is a point stored
			{
				line[0] = ' ';												// Set first character to 0. This will allow us to use sscanf
				int vertexNumber[9] = { 0, 0, 0, 0, 0, 0, 0, 0, 0 };//9?
				sscanf(line.c_str(), "%i/%i/%i %i/%i/%i %i/%i/%i",								// Read integers from the line:  f 1 2 3
					&vertexNumber[0],										// First point of our triangle. This is an 
					&vertexNumber[1],										// pointer to our vertexBuffer list
					&vertexNumber[2],										// pointer to our vertexBuffer list
					&vertexNumber[3],										// pointer to our vertexBuffer list
					&vertexNumber[4],										// pointer to our vertexBuffer list
					&vertexNumber[5],										// pointer to our vertexBuffer list
					&vertexNumber[6],										// pointer to our vertexBuffer list
					&vertexNumber[7],										// pointer to our vertexBuffer list
					&vertexNumber[8]);										// each point represents an X,Y,Z.
				vertexNumber[0] -= 1;										// OBJ file starts counting from 1
				vertexNumber[1] -= 1;										// OBJ file starts counting from 1
				vertexNumber[2] -= 1;										// OBJ file starts counting from 1
				vertexNumber[3] -= 1;										// OBJ file starts counting from 1
				vertexNumber[4] -= 1;										// OBJ file starts counting from 1
				vertexNumber[5] -= 1;
				vertexNumber[6] -= 1;										// OBJ file starts counting from 1
				vertexNumber[7] -= 1;										// OBJ file starts counting from 1
				vertexNumber[8] -= 1;
				//cout << "\n\nFaces:\n";
			/*	cout << vertexNumber[0] << '/' << vertexNumber[1] << '/' << vertexNumber[2] << ' ' <<
					 vertexNumber[3] << '/' << vertexNumber[4] << '/' << vertexNumber[5] << ' ' <<
					 vertexNumber[6] << '/' << vertexNumber[7] << '/' << vertexNumber[8] << ' ' << '\n';
			*/
				int tCounter = 0;
				for (int i = 0; i < POINTS_PER_VERTEX; i++)
				{
					Faces_Triangles[triangle_index + tCounter] = vertexBuffer[3 * vertexNumber[i]];
					Faces_Triangles[triangle_index + tCounter + 1] = vertexBuffer[3 * vertexNumber[i] + 1];
					Faces_Triangles[triangle_index + tCounter + 2] = vertexBuffer[3 * vertexNumber[i] + 2];
					//if (i == 3)
					//{
					//	tCounter = 0;
					//	triangle_index += TOTAL_FLOATS_IN_TRIANGLE;
					//}
					//else if (i == 6)
					//{
					//	tCounter = 0;
					//	triangle_index += TOTAL_FLOATS_IN_TRIANGLE;
					//}
					tCounter += POINTS_PER_VERTEX;
				}
				tCounter = 0;
				triangle_index += TOTAL_FLOATS_IN_TRIANGLE;

				for (int i = 0; i < POINTS_PER_VERTEX; i++)
				{
					Faces_Triangles[triangle_index + tCounter] = vertexBuffer[3 * vertexNumber[i+3]];
					Faces_Triangles[triangle_index + tCounter + 1] = vertexBuffer[3 * vertexNumber[i+3] + 1];
					Faces_Triangles[triangle_index + tCounter + 2] = vertexBuffer[3 * vertexNumber[i+3] + 2];
					tCounter += POINTS_PER_VERTEX;
				}
				tCounter = 0;
				triangle_index += TOTAL_FLOATS_IN_TRIANGLE;
				
				for (int i = 0; i < POINTS_PER_VERTEX; i++)
				{
					Faces_Triangles[triangle_index + tCounter] = vertexBuffer[3 * vertexNumber[i+6]];
					Faces_Triangles[triangle_index + tCounter + 1] = vertexBuffer[3 * vertexNumber[i+6] + 1];
					Faces_Triangles[triangle_index + tCounter + 2] = vertexBuffer[3 * vertexNumber[i+6] + 2];
					tCounter += POINTS_PER_VERTEX;
				}
				triangle_index += TOTAL_FLOATS_IN_TRIANGLE;

				float coord1[3] = { Faces_Triangles[triangle_index], Faces_Triangles[triangle_index + 1], Faces_Triangles[triangle_index + 2] };
				float coord2[3] = { Faces_Triangles[triangle_index + 3], Faces_Triangles[triangle_index + 4], Faces_Triangles[triangle_index + 5] };
				float coord3[3] = { Faces_Triangles[triangle_index + 6], Faces_Triangles[triangle_index + 7], Faces_Triangles[triangle_index + 8] };
				float coord4[3] = { Faces_Triangles[triangle_index + 9], Faces_Triangles[triangle_index + 10], Faces_Triangles[triangle_index + 11] };
				float coord5[3] = { Faces_Triangles[triangle_index + 12], Faces_Triangles[triangle_index + 13], Faces_Triangles[triangle_index + 14] };
				float coord6[3] = { Faces_Triangles[triangle_index + 15], Faces_Triangles[triangle_index + 16], Faces_Triangles[triangle_index + 17] };
				float coord7[3] = { Faces_Triangles[triangle_index + 18], Faces_Triangles[triangle_index + 19], Faces_Triangles[triangle_index + 20] };
				float coord8[3] = { Faces_Triangles[triangle_index + 21], Faces_Triangles[triangle_index + 22], Faces_Triangles[triangle_index + 23] };
				float coord9[3] = { Faces_Triangles[triangle_index + 24], Faces_Triangles[triangle_index + 25], Faces_Triangles[triangle_index + 26] };
				
				float *norm = this->calculateNormal(coord1, coord2, coord3);
				float *norm1 = this->calculateNormal(coord4, coord5, coord6);
				float *norm2 = this->calculateNormal(coord7, coord8, coord9);

				tCounter = 0;
				for (int i = 0; i < 3*POINTS_PER_VERTEX; i++)
				{
					normals[normal_index + tCounter] = norm[0];
					normals[normal_index + tCounter + 1] = norm[1];
					normals[normal_index + tCounter + 2] = norm[2];
					tCounter += POINTS_PER_VERTEX;
					if (i == 3)
					{
						tCounter = 0;
						normal_index += TOTAL_FLOATS_IN_TRIANGLE;
						norm = norm1;
					}
					else if (i == 6)
					{
						tCounter = 0;
						normal_index += TOTAL_FLOATS_IN_TRIANGLE;
						norm = norm2;
					}
					
				}
				triangle_index += TOTAL_FLOATS_IN_TRIANGLE;
				normal_index += TOTAL_FLOATS_IN_TRIANGLE;
				TotalConnectedTriangles += TOTAL_FLOATS_IN_TRIANGLE;
			}
		}
		objFile.close();														// Close OBJ file
		this->pos.x = 0.0;		// initiate position of object
		this->pos.y = 3.5;
		this->pos.z = 10.0;
		cout << "File opened successfully";
		cout << "Vertex:\n";
		for (int i = 0; i < 100; i+=3)
		{
			cout << vertexBuffer[i] << ' ' << vertexBuffer[i+1] << ' ' << vertexBuffer[i+2] << '\n';
		}

	}
	else cout << "Unable to open file";
	return 0;
}

float* GraphicObject::calculateNormal(float *coord1, float *coord2, float *coord3)
{
	/* calculate Vector1 and Vector2 */
	float va[3], vb[3], vr[3], val;
	va[0] = coord1[0] - coord2[0];
	va[1] = coord1[1] - coord2[1];
	va[2] = coord1[2] - coord2[2];

	vb[0] = coord1[0] - coord3[0];
	vb[1] = coord1[1] - coord3[1];
	vb[2] = coord1[2] - coord3[2];

	/* cross product */
	vr[0] = va[1] * vb[2] - vb[1] * va[2];
	vr[1] = vb[0] * va[2] - va[0] * vb[2];
	vr[2] = va[0] * vb[1] - vb[0] * va[1];

	/* normalization factor */
	val = glm::sqrt(vr[0] * vr[0] + vr[1] * vr[1] + vr[2] * vr[2]);

	float norm[3];
	norm[0] = vr[0] / val;
	norm[1] = vr[1] / val;
	norm[2] = vr[2] / val;

	return norm;
}

void GraphicObject::Release()
{
	free(this->Faces_Triangles);
	free(this->normals);
	free(this->vertexBuffer);
}

void GraphicObject::Draw()
{
	glPushMatrix();
	glTranslatef(pos.x, pos.y, pos.z);
	glRotatef(0.0, 0, 0, 1);
	glColor3fv(Color);

	glEnableClientState(GL_VERTEX_ARRAY);						// Enable vertex arrays
	glEnableClientState(GL_NORMAL_ARRAY);						// Enable normal arrays
	glVertexPointer(3, GL_FLOAT, 1, Faces_Triangles);			// Vertex Pointer to triangle array
	glNormalPointer(GL_FLOAT, 1, normals);						// Normal pointer to normal array
	glDrawArrays(GL_TRIANGLES, 1, TotalConnectedTriangles);		// Draw the triangles
	//glBufferData(GL_ARRAY_BUFFER, OBJvertices.size() * sizeof(glm::vec3), &OBJvertices[0], GL_STATIC_DRAW);

	glDisableClientState(GL_VERTEX_ARRAY);						// Disable vertex arrays
	glDisableClientState(GL_NORMAL_ARRAY);						// Disable normal arrays
	
	glPopMatrix();
	
	// new (default material)
	GLfloat defaultAmbient[] = { 0.2, 0.2, 0.2, 1 };
	GLfloat defaultDiffuse[] = { 0.8, 0.8, 0.8, 1 };
	GLfloat defaultSpecular[] = { 0, 0, 0, 1 };
	GLfloat defaultShininess = 0;
	GLfloat defaultEmission[] = { 0, 0, 0, 1 };

	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, defaultAmbient);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, defaultDiffuse);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, defaultSpecular);
	glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, defaultShininess);
	glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, defaultEmission);
}

