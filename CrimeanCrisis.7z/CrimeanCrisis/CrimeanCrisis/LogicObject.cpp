#include "LogicObject.h"


LogicObject::LogicObject()
{
}


LogicObject::~LogicObject()
{
}
