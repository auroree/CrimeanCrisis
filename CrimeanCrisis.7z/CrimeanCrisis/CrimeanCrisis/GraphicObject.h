#pragma once

#define _CRT_SECURE_NO_WARNINGS
#define POINTS_PER_VERTEX 3
#define TOTAL_FLOATS_IN_TRIANGLE 9

//STARE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <iostream>
#include "lib/GL/glew.h"
#include "lib/GLFW/glfw3.h"
#include "lib/glm/glm.hpp"
#include "lib/glm/gtc/matrix_transform.hpp"
#include <vector>
//NOWE
#include <windows.h>
#include <fstream>
#include <stdio.h>
#include <string.h>
#include "lib/GL/gl.h"
#include "lib/GL/glu.h"
#include "lib/GL/glut.h"
#include <sstream>
#include <fstream>
#include <string>
#include <cmath>
#include "Types.h"


#define KEY_ESCAPE 27

using namespace glm;
using namespace std;

class GraphicObject
{
public:
	GraphicObject();
	virtual ~GraphicObject();
	//STARE
	virtual bool loadOBJ(const char *path, const char * texturePath);
	virtual bool loadTexture(const char* s);
	virtual void Update() {};
	GraphicObject operator=(const GraphicObject &);
	virtual vector< glm::vec3 > getVertices();

	// NOWE
	float* calculateNormal(float* coord1, float* coord2, float* coord3);
	int alternateLoad(char *path);	// Loads the model
	void Draw();					// Draws the model on the screen
	void Release();					// Release the model

private:
	vector< unsigned int > vertexIndices, uvIndices, normalIndices;
	// loadOBJ variables
	vector< glm::vec3 > OBJvertices;
	vector< glm::vec2 > OBJuvs;
	vector< glm::vec3 > OBJnormals;

	Vector pos;
	float Color[4];

	float* normals;							// Stores the normals
	float* Faces_Triangles;					// Stores the triangles
	float* vertexBuffer;					// Stores the points which make the object
	long TotalConnectedPoints;				// Stores the total number of connected verteces
	long TotalConnectedTriangles;			// Stores the total number of connected triangles
};

