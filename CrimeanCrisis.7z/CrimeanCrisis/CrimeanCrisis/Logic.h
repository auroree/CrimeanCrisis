#pragma once

class Logic
{
public:
	Logic();
	~Logic();
};

