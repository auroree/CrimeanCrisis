#pragma once

class LogicObject
{
public:
	LogicObject();
	virtual ~LogicObject();
};

