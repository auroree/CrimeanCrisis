#include "Communicator.h"


Communicator::Communicator()
{
}


Communicator::~Communicator()
{
}
