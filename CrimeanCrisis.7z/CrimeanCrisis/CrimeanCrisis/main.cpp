﻿#include "Glowny_kontroler.h"
//#undef main
int wmain(int argc, char /*const*/ *argv[])
{


	GraphicObject *obj = new GraphicObject();
	obj->alternateLoad("models/t1.obj");
	//obj->loadOBJ("models/t1.obj", "grafiki/tex1.bmp");
	glutInit(&argc, argv);                                      // GLUT initialization
	RendController::init(obj);

	glutMainLoop();

	Glowny_kontroler kontroler;
	kontroler.Start();		//tu jest główna pętla gry
	return 0;
}