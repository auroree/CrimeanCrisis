#include "Logic.h"


Logic::Logic()
{
}


Logic::~Logic()
{
}
